# My Happy Home registration with Google Sheets

This version is a static, mobile-friendly landing page that can stay on GitHub Pages. The registration modal collects only:

- Full name
- Email address
- Phone number
- Required consent

The form sends registrations to a Google Apps Script web app, which validates the submission and writes it to a private Google Sheet. No Python server is required.

## Included files

- `index.html` — landing page and registration form
- `privacy.html` — starter privacy notice that must be reviewed before launch
- `static/registration.js` — registration modal and submission handling
- `static/promo-breads.jpg` — promotional image
- `google-apps-script/Code.gs` — private Google Sheet backend

## 1. Create the private Google Sheet

1. Sign in to the Google account that will own the registrations.
2. Create a blank Google Sheet. A name such as `My Happy Home Registrations` is recommended.
3. Keep the Sheet sharing setting **Restricted**. Do not publish it to the web.
4. In the Sheet, select **Extensions > Apps Script**.
5. Delete the example code and paste the complete contents of `google-apps-script/Code.gs`.
6. Save the Apps Script project.
7. Select the `setup` function at the top of the editor and click **Run** once.
8. Approve the permissions requested by Google. The script will create a `Registrations` tab and store the Sheet ID privately in Script Properties.

The Sheet will contain these columns:

`Submitted At`, `Registration ID`, `Full Name`, `Email`, `Phone Number`, `Consent Accepted At`, and `Terms Version`.

## 2. Deploy Google Apps Script

1. In Apps Script, click **Deploy > New deployment**.
2. Choose **Web app** as the deployment type.
3. Set **Execute as** to **Me**.
4. Set **Who has access** to **Anyone** so customers are not required to sign in to Google.
5. Click **Deploy** and complete the authorization prompt.
6. Copy the production Web app URL. It must end with `/exec`; do not use the testing URL ending in `/dev`.

If you edit `Code.gs` later, open **Deploy > Manage deployments**, edit the deployment, select **New version**, and redeploy.

## 3. Connect the landing page

Open `index.html` and find this line:

```html
data-endpoint="PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE"
```

Replace only the placeholder with the `/exec` URL copied from Apps Script:

```html
data-endpoint="https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec"
```

Do not put Google passwords, API keys, Sheet IDs, or other secrets in `index.html` or `registration.js`. The Apps Script URL itself is intended to receive public form submissions; the Google Sheet must remain private.

## 4. Test before publishing

From this folder, run a small local web server:

```bash
python -m http.server 8000
```

Open `http://localhost:8000`, submit a test registration, and confirm that exactly one row appears in the `Registrations` tab. Test again on a phone-sized screen.

The form accepts replies only from the Google Apps Script response domains and matches each reply to a one-time browser submission token. The Apps Script backend also validates field lengths, checks consent, uses a honeypot and time check, prevents simultaneous write collisions, blocks spreadsheet-formula injection, and treats an identical email-and-phone combination as an existing registration.

## 5. Publish on GitHub Pages

Upload these items to the root of the `hrosalessss/myhappyhome` repository:

- `index.html`
- `privacy.html`
- the complete `static` folder

The `google-apps-script` folder is setup source code and does not need to be served by GitHub Pages.

After pushing the files, test the live registration form and verify that the Google Sheet receives the row. The allowed response origins already include:

- `https://hrosalessss.github.io`
- `https://myhappyhomeexclusives.com`
- `https://www.myhappyhomeexclusives.com`

If the site moves to another domain, add its exact origin to `ALLOWED_PARENT_ORIGINS` in `Code.gs` and deploy a new Apps Script version.

## Privacy and operations

- Keep the Sheet restricted to authorized staff.
- Turn on two-step verification for the Google account that owns the Sheet.
- Review and approve `privacy.html` before launch.
- Decide and document how long registrations will be retained, then delete them after that period.
- Regularly create a protected backup while the promotion is active.
- Google Apps Script has quotas and is appropriate for a small promotion. For higher traffic or stronger abuse protection, add a server-verified CAPTCHA or move submissions behind a dedicated backend.
