const REGISTRATION_SHEET_NAME = "Registrations";
const TERMS_VERSION = "2026-09-10";
const MAX_REQUEST_BYTES = 4096;
const ALLOWED_PARENT_ORIGINS = [
  "https://myhappyhomeexclusives.com",
  "https://www.myhappyhomeexclusives.com",
  "https://hrosalessss.github.io",
  "http://localhost:8000",
  "http://127.0.0.1:8000",
];

const HEADERS = [
  "Submitted At",
  "Registration ID",
  "Full Name",
  "Email",
  "Phone Number",
  "Consent Accepted At",
  "Terms Version",
];

/**
 * Run this once from Extensions > Apps Script while this script is attached
 * to the private Google Sheet. It stores the Sheet ID privately and prepares
 * the Registrations tab.
 */
function setup() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  if (!spreadsheet) {
    throw new Error("Open this script from the Google Sheet before running setup().");
  }

  PropertiesService.getScriptProperties().setProperty(
    "REGISTRATION_SPREADSHEET_ID",
    spreadsheet.getId(),
  );
  ensureRegistrationSheet_(spreadsheet);
}

/**
 * Receives the landing-page form, validates it, and writes one safe row.
 */
function doPost(event) {
  const parameters = event && event.parameter ? event.parameter : {};
  const submissionToken = cleanSingleLine_(parameters.submission_token, 80);
  const parentOrigin = allowedParentOrigin_(parameters.page_origin);

  try {
    if (event.postData && event.postData.length > MAX_REQUEST_BYTES) {
      return response_(false, submissionToken, parentOrigin, "The registration was too large. Please try again.");
    }

    // Quietly accept bot submissions that fill the hidden field, but do not
    // save them or reveal that the anti-spam check was triggered.
    if (cleanSingleLine_(parameters.website, 200)) {
      return response_(true, submissionToken, parentOrigin, successMessage_());
    }

    if (!/^[A-Za-z0-9-]{16,80}$/.test(submissionToken)) {
      return response_(false, "", parentOrigin, "Please reopen the registration form and try again.");
    }

    const startedAt = Number(parameters.form_started_at || 0);
    const elapsed = Date.now() - startedAt;
    if (!startedAt || elapsed < 800 || elapsed > 2 * 60 * 60 * 1000) {
      return response_(false, submissionToken, parentOrigin, "Please reopen the registration form and try again.");
    }

    const fullName = cleanSingleLine_(parameters.full_name, 121);
    const email = cleanSingleLine_(parameters.email, 255).toLowerCase();
    const phoneNumber = cleanSingleLine_(parameters.mobile_number, 31);
    const phoneDigits = phoneNumber.replace(/\D/g, "");
    const consent = String(parameters.consent || "");

    if (fullName.length < 2 || fullName.length > 120) {
      return response_(false, submissionToken, parentOrigin, "Please enter your full name.");
    }
    if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
      return response_(false, submissionToken, parentOrigin, "Please enter a valid email address.");
    }
    if (
      phoneNumber.length > 30 ||
      !/^[+()\d\s.-]+$/.test(phoneNumber) ||
      phoneDigits.length < 7 ||
      phoneDigits.length > 15
    ) {
      return response_(false, submissionToken, parentOrigin, "Please enter a valid phone number.");
    }
    if (consent !== "yes") {
      return response_(false, submissionToken, parentOrigin, "Please accept the consent statement to continue.");
    }

    const spreadsheetId = PropertiesService.getScriptProperties().getProperty(
      "REGISTRATION_SPREADSHEET_ID",
    );
    if (!spreadsheetId) {
      return response_(false, submissionToken, parentOrigin, "Registration is temporarily unavailable.");
    }

    const lock = LockService.getScriptLock();
    if (!lock.tryLock(10000)) {
      return response_(false, submissionToken, parentOrigin, "Registration is busy. Please try again.");
    }

    try {
      const spreadsheet = SpreadsheetApp.openById(spreadsheetId);
      const sheet = ensureRegistrationSheet_(spreadsheet);

      // Treat the same email-and-phone combination as an existing
      // registration. The visitor receives the same message either way.
      if (!isExistingRegistration_(sheet, email, phoneDigits)) {
        const submittedAt = new Date();
        const registrationId = `MHH-${Utilities.getUuid().toUpperCase()}`;
        const nextRow = sheet.getLastRow() + 1;

        sheet.getRange(nextRow, 1, 1, HEADERS.length).setValues([[
          submittedAt,
          safeSheetText_(registrationId),
          safeSheetText_(fullName),
          safeSheetText_(email),
          safeSheetText_(phoneNumber),
          submittedAt,
          safeSheetText_(TERMS_VERSION),
        ]]);
        SpreadsheetApp.flush();
      }
    } finally {
      lock.releaseLock();
    }

    return response_(true, submissionToken, parentOrigin, successMessage_());
  } catch (error) {
    // Avoid logging or returning the submitted personal information.
    console.error("Registration write failed: " + String(error && error.message));
    return response_(false, submissionToken, parentOrigin, "We could not save your registration. Please try again.");
  }
}

function ensureRegistrationSheet_(spreadsheet) {
  let sheet = spreadsheet.getSheetByName(REGISTRATION_SHEET_NAME);
  if (!sheet) sheet = spreadsheet.insertSheet(REGISTRATION_SHEET_NAME);

  if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]);
    sheet.setFrozenRows(1);
    sheet.getRange("A:A").setNumberFormat("yyyy-mm-dd hh:mm:ss");
    sheet.getRange("F:F").setNumberFormat("yyyy-mm-dd hh:mm:ss");
    sheet.getRange("B:E").setNumberFormat("@");
    sheet.getRange("G:G").setNumberFormat("@");
    sheet.autoResizeColumns(1, HEADERS.length);
  }

  return sheet;
}

function isExistingRegistration_(sheet, email, phoneDigits) {
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return false;

  const numberOfRows = Math.min(lastRow - 1, 5000);
  const firstRow = lastRow - numberOfRows + 1;
  const rows = sheet.getRange(firstRow, 4, numberOfRows, 2).getDisplayValues();

  return rows.some(function (row) {
    return (
      String(row[0]).trim().toLowerCase() === email &&
      String(row[1]).replace(/\D/g, "") === phoneDigits
    );
  });
}

function cleanSingleLine_(value, maximumLength) {
  return String(value || "")
    .replace(/[\u0000-\u001F\u007F]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, maximumLength);
}

function safeSheetText_(value) {
  const text = String(value || "");
  return /^[=+\-@]/.test(text) ? "'" + text : text;
}

function allowedParentOrigin_(requestedOrigin) {
  const requested = String(requestedOrigin || "");
  return ALLOWED_PARENT_ORIGINS.indexOf(requested) !== -1
    ? requested
    : ALLOWED_PARENT_ORIGINS[0];
}

function successMessage_() {
  return "Thank you! Your registration has been received. Please keep your original receipt for redemption.";
}

function response_(ok, submissionToken, parentOrigin, message) {
  const payload = JSON.stringify({
    source: "mhh-registration",
    ok: Boolean(ok),
    submissionToken: String(submissionToken || ""),
    message: String(message || ""),
  }).replace(/</g, "\\u003c");
  const targetOrigin = JSON.stringify(parentOrigin);
  const html =
    "<!doctype html><html><head><meta charset=\"utf-8\"></head><body>" +
    "<p>Registration response</p>" +
    "<script>window.parent.postMessage(" + payload + "," + targetOrigin + ");<\/script>" +
    "</body></html>";

  return HtmlService.createHtmlOutput(html)
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
